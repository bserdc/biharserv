</main>
    <footer class="site-footer">
      <div class="footer-grid section-shell">
        <div>
          <img class="footer-logo" src="./assets/logo.png" alt="Council logo">
          <p>Building an educated, confident and empowered Bihar—one student at a time.</p>
        </div>
        <div>
          <h3>Quick links</h3>
          <a href="./about.html">About us</a>
          <a href="./awards.html">Awards &amp; recognition</a>
          <a href="./gallery.php">Gallery</a>
        </div>
        <div>
          <h3>Contact</h3>
          <p>Neha Bhawan, Near BNMV College,<br>Sahugarh, Madhepura, Bihar 852113</p>
          <a href="tel:+917070530080">+91 7070530080</a>
          <a href="mailto:adarshbiharsiksha@gmail.com">adarshbiharsiksha@gmail.com</a>
        </div>
      </div>
      <div class="copyright section-shell">
        © <span data-current-year></span> <?= htmlspecialchars($settings['site_title'] ?? APP_NAME) ?>. All rights reserved.
      </div>
    </footer>
    <script src="./script.js"></script>
  </body>
</html>

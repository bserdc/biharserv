<?php
/**
 * Reusable header partial for dynamic PHP pages.
 */

$currentPage = $currentPage ?? basename($_SERVER['PHP_SELF'] ?? 'index.php');
$navItems = [
    ['label' => 'Home', 'href' => './index.php'],
    ['label' => 'About Us', 'href' => './about.html'],
    ['label' => 'Our Work', 'href' => './index.php#initiatives'],
    ['label' => 'Awards & Recognition', 'href' => './awards.html'],
    ['label' => 'Gallery', 'href' => './gallery.php'],
    ['label' => 'Contact', 'href' => './contact.html'],
];
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?= htmlspecialchars($settings['site_title'] ?? APP_NAME) ?>">
    <title><?= htmlspecialchars($pageTitle ?? ($settings['site_title'] ?? APP_NAME)) ?></title>
    <link rel="stylesheet" href="./styles.css">
  </head>
  <body>
    <header class="site-header" id="home">
      <div class="header-wrap">
        <a class="brand" href="./index.php" aria-label="Bihar State Educational Development and Research Council">
          <img src="./assets/logo.png" alt="Council logo">
        </a>
        <div class="header-center">
          <h2 class="header-hindi">बिहार राज्य शैक्षणिक विकास एवं अनुसंधान परिषद</h2>
          <p class="header-english">Bihar State Educational Development &amp; Research Council</p>
        </div>
        <div class="socials" aria-label="Social media links">
          <a class="social-link facebook" href="#" aria-label="Facebook" title="Facebook">
            <img src="./assets/icons/facebook.svg" alt="Facebook icon">
          </a>
          <a class="social-link youtube" href="#" aria-label="YouTube" title="YouTube">
            <img src="./assets/icons/youtube.svg" alt="YouTube icon">
          </a>
          <a class="social-link instagram" href="#" aria-label="Instagram" title="Instagram">
            <img src="./assets/icons/instagram.svg" alt="Instagram icon">
          </a>
        </div>
        <button class="menu-toggle" aria-label="Open menu" aria-expanded="false">☰</button>
      </div>
      <div class="nav-shell">
        <nav class="main-nav" aria-label="Main navigation">
          <?php foreach ($navItems as $item): ?>
            <?php
              $isActive = ($currentPage === basename($item['href'])) || ($currentPage === 'index.php' && $item['href'] === './index.php');
            ?>
            <a href="<?= htmlspecialchars($item['href']) ?>" class="<?= $isActive ? 'active' : '' ?>"><?= htmlspecialchars($item['label']) ?></a>
          <?php endforeach; ?>
        </nav>
      </div>
      <div class="report-bar">
        <a href="./form.html"><?= htmlspecialchars($settings['report_bar'] ?? SITE_DEFAULTS['report_bar']) ?></a>
      </div>
    </header>
    <main>
